<!DOCTYPE html>
<html lang="en">
<head>
  <title>Stock Forecast</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
      }
      
      td, th {
        border: 1px solid #dddddd;c
        text-align: left;
        padding: 8px;
      }
      
      tr:nth-child(even) {
        background-color: #dddddd;
      }
      </style>
      <script>
          function magnify(imgID, zoom) {
            var img, glass, w, h, bw;
            img = document.getElementById(imgID);
            /*create magnifier glass:*/
            glass = document.createElement("DIV");
            glass.setAttribute("class", "img-magnifier-glass");
            /*insert magnifier glass:*/
            img.parentElement.insertBefore(glass, img);
            /*set background properties for the magnifier glass:*/
            glass.style.backgroundImage = "url('" + img.src + "')";
            glass.style.backgroundRepeat = "no-repeat";
            glass.style.backgroundSize = (img.width * zoom) + "px " + (img.height * zoom) + "px";
            bw = 3;
            w = glass.offsetWidth / 2;
            h = glass.offsetHeight / 2;
            /*execute a function when someone moves the magnifier glass over the image:*/
            glass.addEventListener("mousemove", moveMagnifier);
            img.addEventListener("mousemove", moveMagnifier);
            /*and also for touch screens:*/
            glass.addEventListener("touchmove", moveMagnifier);
            img.addEventListener("touchmove", moveMagnifier);
            function moveMagnifier(e) {
              var pos, x, y;
              /*prevent any other actions that may occur when moving over the image*/
              e.preventDefault();
              /*get the cursor's x and y positions:*/
              pos = getCursorPos(e);
              x = pos.x;
              y = pos.y;
              /*prevent the magnifier glass from being positioned outside the image:*/
              if (x > img.width - (w / zoom)) {x = img.width - (w / zoom);}
              if (x < w / zoom) {x = w / zoom;}
              if (y > img.height - (h / zoom)) {y = img.height - (h / zoom);}
              if (y < h / zoom) {y = h / zoom;}
              /*set the position of the magnifier glass:*/
              glass.style.left = (x - w) + "px";
              glass.style.top = (y - h) + "px";
              /*display what the magnifier glass "sees":*/
              glass.style.backgroundPosition = "-" + ((x * zoom) - w + bw) + "px -" + ((y * zoom) - h + bw) + "px";
            }
            function getCursorPos(e) {
              var a, x = 0, y = 0;
              e = e || window.event;
              /*get the x and y positions of the image:*/
              a = img.getBoundingClientRect();
              /*calculate the cursor's x and y coordinates, relative to the image:*/
              x = e.pageX - a.left;
              y = e.pageY - a.top;
              /*consider any page scrolling:*/
              x = x - window.pageXOffset;
              y = y - window.pageYOffset;
              return {x : x, y : y};
            }
          }
          </script>

</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
    <img src="adani.jpeg" style="width:40px;" class="rounded-pill">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mynavbar">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active" href="#">HOME</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">ABOUT</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="adani lm.html">Leadership message</a></li>
            <li><a class="dropdown-item" href="adani bod.html">Board of Directors</a></li>
            <li><a class="dropdown-item" href="adani timeline.html">Timeline</a></li>
          </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="adani-investors.html">INVESTORS</a>
          </li> 
        <li class="nav-item">
          <a class="nav-link" href="#">CONTACT</a>
        </li>  
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="text" placeholder="Search">
        <button class="btn btn-primary" type="button">Search</button>
      </form>
    </div>
  </div>
</nav>
<header><center><h2 style="color:#7e1774">ADANI TRANSMISSION LIMITED</h2></center></header>
<div style="justify-content: center ;align-items: center;display:flex">
  <div class="img-magnifier-container">
    <img id="myimage" src="adani2.jpg" width="600" height="400">
    <script>
        magnify("myimage", 2);
        </script>
          <table class="table table-bordered">
        <tr>
          <td>PREVIOUS CLOSE</td>
          <td>₹1050.05</td>
        </tr>
        <tr>
          <td>DAY RANGE</td>
          <td>₹1048.05-₹1056.20</td>
        </tr>
        <tr>
          <td>MARKET CAP</td>
          <td>1.17T INR</td>
        </tr>
        <tr>
          <td>AVG VOLUME</td>
          <td>1.81M</td>
        </tr>
        <tr>
          <td>P/E RATIO</td>
          <td>97.91</td>
        </tr>
        <tr>
          <td>DIVIDEND YIELD</td>
          <td>-</td>
        </tr>
        <tr>
            <td>PRIMARY EXCHANGE</td>
            <td>NSE</td>
        </tr>
      </table>
      </div>
      </div>
<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
  </div>
  
  <!-- The slideshow/carousel -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <center><img src="as2.jpg" alt="not found" class="d-block" width:"400" height:"300"></center>
    </div>
    <div class="carousel-item">
      <center><img src="ad1.jpg" alt="not found" class="d-block" width:"400" height:"300"></center>
    </div>
  </div>
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>
<table class="table table-bordered">
    <tr>
      <th>(INR)</th>
      <th>DEC 2023 &#9432;</th>
      <th>Y/Y CHANGE</th>
    </tr>
    <tr>
      <td>Revenue</td>
      <td>45.63B</td>
      <td>&uarr;28.47&#37;</td>
    </tr>
    <tr>
      <td>Operating expense</td>
      <td>12.88B</td>
      <td>&uarr;25.36&#37;</td>
    </tr>
    <tr>
      <td>Net income</td>
      <td>3.25B</td>
      <td>&darr;-31.56&#37;</td>
    </tr>
    <tr>
      <td>Net profit margin</td>
      <td>7.12</td>
      <td>&darr;-46.75&#37;</td>
    </tr>
    <tr>
      <td>Earnings per share</td>
      <td>-</td>
      <td>-</td>
    </tr>
    <tr>
      <td>EBITDA</td>
      <td>14.57B</td>
      <td>&uarr;3.21&#37;</td>
    </tr>
    <tr>
        <td>Effective tax rate</td>
        <td>32.33&#37;</td>
        <td>-</td>
    </tr>
  </table>

</body>
</html>


