<!DOCTYPE html>
<html lang="en">
<head>
  <title>Stock Forecast</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    p{
      font-family:'Times;';
      font-size: 30px;
    }
.container {
  position: relative;
  text-align: center;
  color: rgb(26, 24, 24);
}
.top-left {
  position: absolute;
  top: 8px;
  left: 16px;
}
table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
      }
      
      td, th {
        border: 1px solid #dddddd;c
        text-align: left;
        padding: 8px;
      }
      
      tr:nth-child(even) {
        background-color: #dddddd;
      }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
    <img src="logo2.jpg" style="width:40px;" class="rounded-pill">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mynavbar">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active" href="#">HOME</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">ABOUT</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="stockmarket.html">Stock Market List</a></li>
            <li><a class="dropdown-item" href="algorithm.html">Algorithm</a></li>
            <li><a class="dropdown-item" href="latest announcement.html">Latest Announcements</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contacts1.html">CONTACT</a>
        </li>  
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="text" placeholder="Search">
        <button class="btn btn-primary" type="button">Search</button>
      </form>
    </div>
  </div>
</nav>
  <h1 style="color:#ff3385cb"><b><center>STOCK FORECAST</center></b></h1>
</div>
<div class="container">
  <img src="sf4(3).jpg" alt="Snow" style="width:100%;">
  <div class="top-left">Stock market prediction is the act of trying to determine the future value of a company stock or other financial instrument traded on an exchange.<br></div>
  <div class="top-left"><br>"With a good perspective on history,<br> we can have a better understanding of the past and present,<br> and thus a clear vision of the future."</div>
<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
  </div>
  
  <!-- The slideshow/carousel -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <center><img src="sf5.jpg" alt="not found" class="d-block" style="width:80%"></center>
    </div>
    <div class="carousel-item">
      <center><img src="calo1.jpg" alt="not found" class="d-block" style="width:80%"></center>
    </div>
    <div class="carousel-item">
      <center><img src="calo2.jpeg" alt="not found" class="d-block" style="width:80%"></center>
    </div>
  </div>
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>
<table class="table table-bordered table-hover">
  <thead class="table-info">
    <tr>
      <th>Company</th>
      <th>City</th>
    </tr>
  </thead>
  <tbody>
    <tr class="table-danger">
      <td><a href="adani boot.html">Adani Transmission Limited</a></td>
      <td>Ahmedabad</td>
    </tr>
    <tr class="table-info">
      <td><a href="HDFC.html">Housing Development Finance Corporation</a></td>
      <td>Mumbai</td>
    </tr>
    <tr class="table-danger">
      <td><a href="reliance.html">Reliance Industries Limited</a></td>
      <td>Mumbai</td>
    </tr>
    <tr class="table-info">
      <td><a href="MRF.html">MRF Limited</a></td>
      <td>Chennai</td>
    </tr>
    <tr class="table-danger">
      <td><a href="indian oil.html">Indian Oil Corporation Limited</a></td>
      <td>New Delhi</td>
    </tr>
    <tr class="table-info">
      <td><a href="icici.html">ICICI Bank Limited</a></td>
      <td>Mumbai</td>
    </tr>
    </tbody>
  </table>
    
  </tbody>

</table>

</body>
</html>


